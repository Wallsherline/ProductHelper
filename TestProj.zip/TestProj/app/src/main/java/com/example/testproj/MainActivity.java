package com.example.testproj;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button button1, button2, button3, button4,button5;
    FragmentAddProduct fragmentAddProduct;
    TextView textDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button1 = (Button)findViewById(R.id.button1);
        button2 = (Button)findViewById(R.id.button2);
        button3 = (Button)findViewById(R.id.button3);
        button4 = (Button)findViewById(R.id.button4);
        button5 = (Button)findViewById(R.id.button5);
        textDate = (TextView)findViewById(R.id.textDate);
        /*FragmentManager manager1 = getSupportFragmentManager();
        FragmentTransaction transaction1 = manager1.beginTransaction();
        fragmentAddProduct = manager1.findFragmentByTag(FragmentAddProduct);
        transaction1.hide(fragmentAddProduct);*/
    }

    public void ChangeFragment(View view){
        Fragment fragment = null;
        switch (view.getId()){
            case R.id.button1:{
                button1.setVisibility(View.INVISIBLE);
                button2.setVisibility(View.INVISIBLE);
                button3.setVisibility(View.INVISIBLE);
                button4.setVisibility(View.INVISIBLE);
                button5.setVisibility(View.INVISIBLE);
                textDate.setVisibility(View.INVISIBLE);
                fragment = new FragmentList();
                break;
            }
            case R.id.button2:{
                button1.setVisibility(View.INVISIBLE);
                button2.setVisibility(View.INVISIBLE);
                button3.setVisibility(View.INVISIBLE);
                button4.setVisibility(View.INVISIBLE);
                button5.setVisibility(View.INVISIBLE);
                textDate.setVisibility(View.INVISIBLE);
                fragment = new FragmentCalendar();
                break;
            }
            case R.id.button3:{
                button1.setVisibility(View.INVISIBLE);
                button2.setVisibility(View.INVISIBLE);
                button3.setVisibility(View.INVISIBLE);
                button4.setVisibility(View.INVISIBLE);
                button5.setVisibility(View.INVISIBLE);
                textDate.setVisibility(View.INVISIBLE);
                fragment = new FragmentSettings();
                break;
            }
            case R.id.button4:{
                button1.setVisibility(View.INVISIBLE);
                button2.setVisibility(View.INVISIBLE);
                button3.setVisibility(View.INVISIBLE);
                button4.setVisibility(View.INVISIBLE);
                button5.setVisibility(View.INVISIBLE);
                textDate.setVisibility(View.INVISIBLE);
                fragment = new FragmentHistory();
                break;
            }
            case R.id.button5:{
                button1.setVisibility(View.INVISIBLE);
                button2.setVisibility(View.INVISIBLE);
                button3.setVisibility(View.INVISIBLE);
                button4.setVisibility(View.INVISIBLE);
                button5.setVisibility(View.INVISIBLE);
                textDate.setVisibility(View.INVISIBLE);
                fragment = new FragmentDataBase();
                break;
            }
        }
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragmentMain, fragment);
        fragmentTransaction.commit();
    }

    public void ReturnFragment(View view){
        Fragment fragment = new FragmentMain();
        if (view.getId() == R.id.buttonList1 || view.getId() == R.id.buttonSetting || view.getId() == R.id.buttonHistory ||view.getId() == R.id.buttonCalendar ||view.getId() == R.id.buttonDataBase){
            button1.setVisibility(View.VISIBLE);
            button2.setVisibility(View.VISIBLE);
            button3.setVisibility(View.VISIBLE);
            button4.setVisibility(View.VISIBLE);
            button5.setVisibility(View.VISIBLE);
            textDate.setVisibility(View.VISIBLE);
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.fragmentMain, fragment);
            fragmentTransaction.commit();
        }
    }
    public void AddProduct(View view) {
        Fragment fragment = null;
        switch (view.getId()) {
            case R.id.buttonAddProduct: {
                fragment = new FragmentAddProduct();
            }
        }
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragmentDataBase, fragment);
        fragmentTransaction.commit();
    }

    public void AddHistory(View view){
        switch (view.getId()){
            case R.id.buttonAddHistory:{
                //.............
                break;
            }
        }
    }
}
